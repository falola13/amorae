import { NextResponse, type NextRequest } from "next/server";

import { getSessionToken } from "@/lib/auth/session";
import { env } from "@/lib/env";

// Same-origin front door for browser calls. The axios client (lib/api/http.ts)
// hits /api/v1/<path>; this forwards to <API_URL>/v1/<path> with the session
// cookie's bearer token attached. The browser never holds the token.
//
// Nothing here is cached: every call carries a user session.
const TIMEOUT_MS = 10_000;

async function forward(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const { path } = await params;
  const token = await getSessionToken();
  const target = new URL(`${env.API_URL}/v1/${path.join("/")}`);
  target.search = request.nextUrl.search;

  const headers: Record<string, string> = { Accept: "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const contentType = request.headers.get("content-type");
  if (contentType) headers["Content-Type"] = contentType;
  const requestId = request.headers.get("x-request-id");
  if (requestId) headers["X-Request-ID"] = requestId;
  if (env.BFF_SECRET) {
    const ip = request.headers.get("x-forwarded-for")?.split(",").at(-1)?.trim() ?? request.headers.get("x-real-ip");
    if (ip) Object.assign(headers, { "X-Client-IP": ip, "X-BFF-Secret": env.BFF_SECRET });
  }

  let upstream: Response;
  try {
    upstream = await fetch(target, {
      method: request.method,
      headers,
      body: request.method === "GET" || request.method === "HEAD" ? undefined : await request.text(),
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch {
    return NextResponse.json({ error: { code: "network_error", message: "We couldn't reach the server. Please try again." } }, { status: 502 });
  }

  const body = await upstream.text();
  const res = new NextResponse(body || null, { status: upstream.status });
  res.headers.set("Cache-Control", "no-store");
  const ct = upstream.headers.get("content-type");
  if (ct) res.headers.set("Content-Type", ct);
  const rid = upstream.headers.get("x-request-id");
  if (rid) res.headers.set("X-Request-ID", rid);
  const retry = upstream.headers.get("retry-after");
  if (retry) res.headers.set("Retry-After", retry);
  return res;
}

export { forward as GET, forward as POST, forward as PATCH, forward as PUT, forward as DELETE };
