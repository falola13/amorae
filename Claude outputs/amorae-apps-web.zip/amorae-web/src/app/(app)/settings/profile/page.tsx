"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";

import { Icon } from "@/components/icons";
import { Main } from "@/components/layout/screen";
import { BottomActions, Button, Field, Initial, Skeleton, Title, TopBar } from "@/components/ui/kit";
import { useCouple, useUpdateProfile } from "@/features/couple/hooks";
import { isApiError } from "@/lib/api/errors";
import { profileSchema, type ProfileInput } from "@/lib/api/schemas";

const ZONES = ["Africa/Lagos", "America/New_York", "Europe/London", "Africa/Nairobi", "Asia/Dubai"];

export default function ProfilePage() {
  const couple = useCouple(); const update = useUpdateProfile();
  const [saved, setSaved] = useState(false);
  const { register, handleSubmit, reset, setError, control, formState: { errors, isDirty } } = useForm<ProfileInput>({ resolver: zodResolver(profileSchema), defaultValues: { display_name: "", email: "", timezone: "Africa/Lagos" } });
  useEffect(() => { const me = couple.data?.me; if (me) reset({ display_name: me.display_name, email: me.email, timezone: me.timezone }); }, [couple.data, reset]);
  const name = useWatch({ control, name: "display_name" });
  if (!couple.data) return <><TopBar back="Settings" backHref="/settings" /><Main><Skeleton /></Main></>;
  const partner = couple.data.partner?.display_name;
  const onSubmit = (v: ProfileInput) =>
    update.mutate(v, {
      onSuccess: () => { reset(v); setSaved(true); setTimeout(() => setSaved(false), 2000); },
      onError: (e) => { if (isApiError(e)) for (const [k, m] of Object.entries(e.fields ?? {})) setError(k as keyof ProfileInput, { message: m }); },
    });
  return (
    <>
      <TopBar back="Settings" backHref="/settings" />
      <form onSubmit={handleSubmit(onSubmit)} className="flex grow flex-col" noValidate>
        <Main className="gap-[26px] pt-3">
          <Title>Profile</Title>
          <div className="flex items-center gap-4"><Initial letter={name?.[0] ?? "A"} size={64} /><div className="flex flex-col"><div className="text-bodylg font-semibold">{name || "You"}</div><div className="text-support text-stone">{partner ? `Praying with ${partner}` : "Waiting for your partner"}</div></div></div>
          <div className="flex flex-col gap-[18px]">
            <Field label="First name" autoComplete="given-name" hint={partner ? `This is what ${partner} sees.` : "This is what your partner will see."} error={errors.display_name?.message} {...register("display_name")} />
            <Field label="Email" type="email" autoComplete="email" inputMode="email" error={errors.email?.message} {...register("email")} />
            <div className="flex flex-col gap-2"><label htmlFor="timezone" className="text-[13px] font-semibold text-stone">Timezone</label>
              <select id="timezone" className="h-[52px] w-full appearance-none rounded-input border border-edge bg-surface px-4 text-[16px] text-ink" {...register("timezone")}>
                {ZONES.map((z) => <option key={z} value={z}>{z.replace("_", " ")}</option>)}
              </select></div>
            <Link href="#password" className="press flex h-[54px] items-center justify-between border-y border-line text-[16px] font-medium text-ink no-underline">Change password<Icon name="right" size={18} className="text-stone" /></Link>
          </div>
        </Main>
        <BottomActions><Button type="submit" disabled={!isDirty && !saved} loading={update.isPending} icon={saved ? "check" : undefined}>{saved ? "Saved" : "Save changes"}</Button></BottomActions>
      </form>
    </>
  );
}
