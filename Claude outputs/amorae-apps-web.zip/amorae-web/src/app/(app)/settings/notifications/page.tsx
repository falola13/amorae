'use client';

import { useCouple } from '@/features/couple/hooks';
import { usePrefs, useSavePrefs } from '@/features/settings/hooks';
import { time12 } from '@/lib/dates';
import type { NotificationPrefs } from '@/lib/api/types';
import { Main } from '@/components/layout/screen';
import { Micro, Para, Skeleton, Switch, Title, TopBar, cx } from '@/components/ui/kit';

function ToggleRow({ label, last, checked, onChange }: { label: string; last?: boolean; checked: boolean; onChange: (v: boolean) => void }) {
  return <div className={cx('flex h-14 items-center gap-4', !last && 'border-b border-line')}><span className="grow text-[16px] font-medium">{label}</span><Switch checked={checked} onChange={onChange} label={label} /></div>;
}
function Group({ label, children }: { label: string; children: React.ReactNode }) {
  return <section className="mt-[22px] flex flex-col"><Micro className="pb-0.5">{label}</Micro>{children}</section>;
}

type BoolKey = { [K in keyof NotificationPrefs]: NotificationPrefs[K] extends boolean ? K : never }[keyof NotificationPrefs];

export default function NotificationSettings() {
  const prefs = usePrefs(); const save = useSavePrefs(); const couple = useCouple();
  const p = prefs.data; const partner = couple.data?.partner?.display_name ?? 'your partner';
  if (!p) return <><TopBar back="Settings" backHref="/settings" /><Main><Skeleton /></Main></>;
  const row = (k: BoolKey, label: string, last?: boolean) => <ToggleRow key={k} label={label} last={last} checked={p[k]} onChange={(v) => save.mutate({ [k]: v })} />;
  return (
    <>
      <TopBar back="Settings" backHref="/settings" />
      <Main>
        <div className="pt-3"><Title>Notifications</Title><Para className="mt-1.5">Few, calm, and only about the two of you.</Para></div>
        <Group label="Faith">
          {row("new_week", "New prayer week")}
          {row("prayer_reminder", "Prayer reminder")}
          <label className={cx('relative flex h-[54px] items-center justify-between pl-4 text-[16px] font-medium', !p.prayer_reminder && 'opacity-50')}>Reminder time
            <span className="tabular flex items-center gap-1.5 font-semibold text-plum">{time12(p.reminder_time)}, every day</span>
            <input type="time" value={p.reminder_time} disabled={!p.prayer_reminder} onChange={(e) => save.mutate({ reminder_time: e.target.value })} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" aria-label="Reminder time" />
          </label>
        </Group>
        <Group label="Plans">{row("event_reminders", "Event reminders")}{row("important_dates", "Important dates", true)}</Group>
        <Group label="Together">{row("appreciation", `Appreciation from ${partner}`)}{row("journal", "Journal entries")}{row("goals", "Goal updates")}{row("challenges", "Challenge reminders", true)}</Group>
        <Para size="support" className="mb-4 mt-4">Never more than one reminder a day.</Para>
      </Main>
    </>
  );
}
