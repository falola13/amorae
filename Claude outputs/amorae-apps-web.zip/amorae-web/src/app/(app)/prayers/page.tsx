"use client";

import { Main } from "@/components/layout/screen";
import { BottomActions, EmptyState, LinkButton, Micro, Para, Segments, Skeleton, Title } from "@/components/ui/kit";
import { PrayerRow } from "@/components/ui/prayer-row";
import { useCouple } from "@/features/couple/hooks";
import { useWeek } from "@/features/prayers/hooks";
import { range } from "@/lib/dates";
import { useNetwork } from "@/lib/store/network";

export default function PrayersPage() {
  const week = useWeek(); const couple = useCouple();
  const isQueued = useNetwork((s) => s.isQueued);
  const w = week.data; const me = couple.data?.me; const partner = couple.data?.partner?.display_name ?? "your partner";
  if (!w || !me) return <Main><div className="pt-4"><Skeleton lines={5} /></div></Main>;
  if (w.status !== "published") {
    const mine = w.setter_id === me.id;
    return (
      <Main>
        <div className="pt-1.5"><Micro>{range(w.week_start, w.week_end, true)}</Micro></div>
        <Title className="mt-2">This week&rsquo;s prayers</Title>
        <EmptyState ghost="dots" title={mine ? "Nothing shared yet." : `${partner} is still writing.`} text={mine ? "Write what’s on your heart and share it when it feels ready." : "You’ll get a quiet nudge the moment the week is shared."}
          cta={mine ? <LinkButton href="/prayers/set">Set this week&rsquo;s prayers</LinkButton> : <LinkButton href="/prayers/mode?quiet=1" icon="moon">Enter quiet prayer</LinkButton>} />
      </Main>
    );
  }
  const done = w.my_completed.length; const total = w.points.length;
  return (
    <>
      <Main>
        <div className="pt-1.5"><Micro>{range(w.week_start, w.week_end, true)} &middot; set by {w.setter_id === me.id ? "you" : partner}</Micro></div>
        <Title className="mt-2">This week&rsquo;s prayers</Title>
        <div className="mt-5 flex flex-col gap-2.5"><Segments total={total} done={done} /><Para size="support">{done} of {total} prayed</Para></div>
        <div className="mt-2 flex flex-col border-t border-line">
          {w.points.map((p, i) => <PrayerRow key={p.id} p={p} index={i} done={w.my_completed.includes(p.id)} href={`/prayers/${p.id}`} note={isQueued((q) => (q.payload as { pointId?: string }).pointId === p.id) ? "Will sync when you’re back online" : undefined} />)}
        </div>
      </Main>
      <BottomActions><LinkButton href="/prayers/mode">{done === total ? "Open prayer mode" : done === 0 ? "Begin praying" : "Continue praying"}</LinkButton></BottomActions>
    </>
  );
}
