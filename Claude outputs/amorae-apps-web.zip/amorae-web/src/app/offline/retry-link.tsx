"use client";

import { buttonClassName } from "@/components/ui/button";

// The service worker serves the offline page *at the URL the user asked
// for*, so reloading retries exactly that page.
export function RetryLink() {
  return (
    <button type="button" className={buttonClassName("primary")} onClick={() => window.location.reload()}>
      Try again
    </button>
  );
}
