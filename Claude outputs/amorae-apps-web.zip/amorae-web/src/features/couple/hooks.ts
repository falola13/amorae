"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { keys } from "@/lib/query/keys";
import { coupleApi } from "./api";

export const useMe = () => useQuery({ queryKey: keys.me, queryFn: coupleApi.me });
export const useCouple = () => useQuery({ queryKey: keys.couple, queryFn: coupleApi.couple });

export function useCreateCouple() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: coupleApi.create, onSuccess: (c) => qc.setQueryData(keys.couple, c) });
}
export function useJoinCouple() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: coupleApi.join, onSuccess: (c) => qc.setQueryData(keys.couple, c) });
}
export function useOnboarding() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: coupleApi.onboarding, onSuccess: (c) => qc.setQueryData(keys.couple, c) });
}
export function useUpdateProfile() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: coupleApi.updateMe, onSuccess: () => { qc.invalidateQueries({ queryKey: keys.me }); qc.invalidateQueries({ queryKey: keys.couple }); } });
}
export const useDeleteAccount = () => useMutation({ mutationFn: coupleApi.deleteMe });
