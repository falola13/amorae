"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { offline } from "@/lib/api/http";
import type { PrayerPoint, PrayerWeek } from "@/lib/api/types";
import { keys } from "@/lib/query/keys";
import { useNetwork } from "@/lib/store/network";
import { prayersApi } from "./api";

export const useWeek = () => useQuery({ queryKey: keys.week, queryFn: prayersApi.current });
export const useHistory = () => useQuery({ queryKey: keys.history, queryFn: prayersApi.history });
export const useWeekById = (id: string) => useQuery({ queryKey: keys.weekById(id), queryFn: () => prayersApi.week(id) });

/** Optimistic: the check draws in at once; the call follows, or is queued when offline. */
export function useSetCompleted() {
  const qc = useQueryClient();
  const enqueue = useNetwork((s) => s.enqueue);
  return useMutation({
    mutationFn: ({ pointId, done }: { pointId: string; done: boolean }) => (done ? prayersApi.complete(pointId) : prayersApi.uncomplete(pointId)),
    onMutate: async ({ pointId, done }) => {
      await qc.cancelQueries({ queryKey: keys.week });
      const prev = qc.getQueryData<PrayerWeek>(keys.week);
      if (prev) qc.setQueryData<PrayerWeek>(keys.week, { ...prev, my_completed: done ? Array.from(new Set([...prev.my_completed, pointId])) : prev.my_completed.filter((x) => x !== pointId) });
      if (offline()) enqueue("prayer.complete", { pointId, done });
      return { prev };
    },
    onError: (_e, _v, ctx) => { if (ctx?.prev && !offline()) qc.setQueryData(keys.week, ctx.prev); },
    onSettled: () => { if (!offline()) qc.invalidateQueries({ queryKey: keys.week }); },
  });
}

function invalidating<A, R>(fn: (a: A) => Promise<R>, ks: ReadonlyArray<readonly string[]>) {
  return function useIt() {
    const qc = useQueryClient();
    return useMutation({ mutationFn: fn, onSettled: () => ks.forEach((k) => qc.invalidateQueries({ queryKey: k })) });
  };
}

export const useSavePoints = invalidating((points: PrayerPoint[]) => prayersApi.savePoints(points), [keys.week]);
export const usePublish = invalidating<void, PrayerWeek>(() => prayersApi.publish(), [keys.week, keys.history]);
export const useSaveReflection = invalidating(({ weekId, text }: { weekId: string; text: string }) => prayersApi.reflection(weekId, text), [keys.history, keys.week, ["prayers", "week"]]);
export const useDemoWeek = invalidating((mode: "partner" | "mine" | "waiting") => prayersApi.demo(mode), [keys.week, keys.history]);
