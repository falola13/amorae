"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import type { NotificationPrefs } from "@/lib/api/types";
import { keys } from "@/lib/query/keys";
import { settingsApi } from "./api";

export const usePrefs = () => useQuery({ queryKey: keys.prefs, queryFn: settingsApi.prefs });

/** Optimistic: the switch flips at once. */
export function useSavePrefs() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: settingsApi.savePrefs,
    onMutate: async (patch) => {
      await qc.cancelQueries({ queryKey: keys.prefs });
      const prev = qc.getQueryData<NotificationPrefs>(keys.prefs);
      if (prev) qc.setQueryData(keys.prefs, { ...prev, ...patch });
      return { prev };
    },
    onError: (_e, _v, ctx) => { if (ctx?.prev) qc.setQueryData(keys.prefs, ctx.prev); },
    onSettled: () => qc.invalidateQueries({ queryKey: keys.prefs }),
  });
}
