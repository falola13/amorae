"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { offline } from "@/lib/api/http";
import type { ChallengeDay, JournalEntry, Memory, Milestone } from "@/lib/api/types";
import type { EventInput, GoalInput } from "@/lib/api/schemas";
import { keys } from "@/lib/query/keys";
import { useNetwork } from "@/lib/store/network";
import { togetherApi as api } from "./api";

export const useEvents = () => useQuery({ queryKey: keys.events, queryFn: api.events });
export const useEvent = (id: string) => useQuery({ queryKey: keys.event(id), queryFn: () => api.event(id), enabled: !!id });
export const useGoals = () => useQuery({ queryKey: keys.goals, queryFn: api.goals });
export const useGoal = (id: string) => useQuery({ queryKey: keys.goal(id), queryFn: () => api.goal(id) });
export const useChallenge = () => useQuery({ queryKey: keys.challenge, queryFn: api.challenge });
export const useJournal = () => useQuery({ queryKey: keys.journal, queryFn: api.journal });
export const useAppreciations = () => useQuery({ queryKey: keys.appreciations, queryFn: api.appreciations });
export const useMemories = () => useQuery({ queryKey: keys.memories, queryFn: api.memories });
export const useMilestones = () => useQuery({ queryKey: keys.milestones, queryFn: api.milestones });

function useInvalidating<A, R>(fn: (a: A) => Promise<R>, ks: ReadonlyArray<readonly string[]>, queueAs?: string) {
  const qc = useQueryClient();
  const enqueue = useNetwork((s) => s.enqueue);
  return useMutation({
    mutationFn: fn,
    onMutate: (a) => { if (queueAs && offline()) enqueue(queueAs, a); },
    onSettled: () => ks.forEach((k) => qc.invalidateQueries({ queryKey: k })),
  });
}

export const useSaveEvent = () => useInvalidating(({ id, input }: { id?: string; input: EventInput }) => (id ? api.updateEvent(id, input) : api.createEvent(input)), [keys.events], "event.save");
export const useCompleteEvent = () => useInvalidating(({ id, done }: { id: string; done: boolean }) => api.completeEvent(id, done), [keys.events]);
export const useChecklist = () => useInvalidating(({ id, item, done }: { id: string; item: string; done: boolean }) => api.checklist(id, item, done), [keys.events]);
export const useCreateGoal = () => useInvalidating((g: GoalInput) => api.createGoal(g), [keys.goals]);
export const useAddProgress = () => useInvalidating(({ id, amount }: { id: string; amount: number }) => api.progress(id, amount), [keys.goals], "goal.progress");
export const useChallengeDay = () => useInvalidating(({ n, patch }: { n: number; patch: Partial<ChallengeDay> }) => api.challengeDay(n, patch), [keys.challenge]);
export const useAddJournal = () => useInvalidating(({ tag, text }: { tag: JournalEntry["tag"]; text: string }) => api.addJournal(tag, text), [keys.journal], "journal.add");
export const useSendAppreciation = () => useInvalidating((text: string) => api.sendAppreciation(text), [keys.appreciations]);
export const useUndoAppreciation = () => useInvalidating((id: string) => api.undoAppreciation(id), [keys.appreciations]);
export const useAddMemory = () => useInvalidating((m: Omit<Memory, "id">) => api.addMemory(m), [keys.memories], "memory.add");
export const useAddMilestone = () => useInvalidating((m: Omit<Milestone, "id">) => api.addMilestone(m), [keys.milestones]);
