"use client";

import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/kit";
import { logoutAction } from "../actions";

export function LogoutButton() {
  const qc = useQueryClient();
  return <Button onClick={async () => { qc.clear(); await logoutAction(); }}>Log out</Button>;
}
