"use server";

import { redirect } from "next/navigation";

import { loginSchema, registerSchema, type LoginInput, type RegisterInput } from "@/lib/api/schemas";
import { clearSession, getSessionToken, setSession } from "@/lib/auth/session";
import { env } from "@/lib/env";
import { toActionError, type ActionError } from "@/lib/forms";
import { safeNext } from "@/lib/safe-next";
import { login, logout, register } from "./api";

// Auth stays on Server Actions because only the server may set the httpOnly
// session cookie (docs/adr/0002). The forms validate with React Hook Form +
// Zod first; the same Zod schema runs again here.

const MOCK_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export async function loginAction(input: LoginInput): Promise<ActionError | undefined> {
  const parsed = loginSchema.safeParse(input);
  if (!parsed.success) return { message: "Check the highlighted fields.", fields: zodFields(parsed.error) };
  const next = safeNext(parsed.data.next);

  if (env.API_MOCK) {
    await setSession("mock-session", new Date(Date.now() + MOCK_TTL_MS).toISOString());
    redirect(next);
  }

  let result;
  try {
    result = await login(parsed.data.email, parsed.data.password);
  } catch (error) {
    return toActionError(error);
  }
  await setSession(result.token, result.expires_at);
  redirect(next);
}

export async function registerAction(input: RegisterInput): Promise<ActionError | undefined> {
  const parsed = registerSchema.safeParse(input);
  if (!parsed.success) return { message: "Check the highlighted fields.", fields: zodFields(parsed.error) };

  if (env.API_MOCK) {
    await setSession("mock-session", new Date(Date.now() + MOCK_TTL_MS).toISOString());
    redirect("/couple?fresh=1");
  }

  let result;
  try {
    result = await register(parsed.data.email, parsed.data.password, parsed.data.display_name);
  } catch (error) {
    return toActionError(error);
  }
  await setSession(result.token, result.expires_at);
  redirect("/couple");
}

export async function logoutAction(): Promise<void> {
  const token = await getSessionToken();
  if (token && !env.API_MOCK) {
    try {
      await logout(token);
    } catch {
      // The cookie is cleared regardless: a failed logout call must never
      // strand the user in a logged-in-looking state.
    }
  }
  await clearSession();
  redirect("/welcome");
}

function zodFields(error: { issues: { path: PropertyKey[]; message: string }[] }): Record<string, string> {
  const out: Record<string, string> = {};
  for (const i of error.issues) { const k = String(i.path[0] ?? ""); if (k && !out[k]) out[k] = i.message; }
  return out;
}
