"use client";

import { useQueryClient } from "@tanstack/react-query";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, type ReactNode } from "react";

import { NetworkBanner } from "@/components/layout/network-banner";
import { Screen } from "@/components/layout/screen";
import { SplashView } from "@/components/layout/splash-view";
import { TabBar } from "@/components/layout/tab-bar";
import { useCouple } from "@/features/couple/hooks";
import { bindNetworkEvents } from "@/lib/store/network";

// The signed-in shell. src/proxy.ts already bounced visitors with no cookie;
// this is the real check: GET /couples/me (a 401 is redirected to /login by
// the axios interceptor). Someone signed in but not yet paired goes to the
// couple step. Prayer mode is distraction-free: no banner, no tab bar.
export function AppShell({ children }: { children: ReactNode }) {
  const couple = useCouple();
  const router = useRouter();
  const path = usePathname();
  const qc = useQueryClient();
  const focused = path.startsWith("/prayers/mode");

  useEffect(() => bindNetworkEvents(() => qc.invalidateQueries()), [qc]);
  useEffect(() => {
    const expired = () => { qc.clear(); router.replace("/login?reason=expired"); };
    window.addEventListener("amorae:session-expired", expired);
    return () => window.removeEventListener("amorae:session-expired", expired);
  }, [qc, router]);
  useEffect(() => {
    if (couple.data && !couple.data.onboarding.couple) router.replace("/couple");
  }, [couple.data, router]);

  if (!couple.data || !couple.data.onboarding.couple) return <SplashView />;
  if (focused) return <>{children}</>;
  return (
    <Screen>
      <div className="shrink-0" style={{ height: "calc(var(--safe-top) + 8px)" }} />
      <NetworkBanner />
      {children}
      <TabBar />
    </Screen>
  );
}
