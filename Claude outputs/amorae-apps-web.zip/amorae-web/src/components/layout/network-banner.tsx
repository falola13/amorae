"use client";

import { Banner } from "@/components/ui/kit";
import { useNetwork } from "@/lib/store/network";

/** Quiet status line. Never a full-screen error: content underneath stays usable. */
export function NetworkBanner() {
  const online = useNetwork((s) => s.online);
  const justSynced = useNetwork((s) => s.justSynced);
  if (!online) return <Banner tone="amber" icon="offline">Offline &middot; Showing your saved content</Banner>;
  if (justSynced) return <Banner tone="green" icon="sync">Back online &middot; {justSynced} {justSynced === 1 ? "change" : "changes"} synced</Banner>;
  return null;
}
