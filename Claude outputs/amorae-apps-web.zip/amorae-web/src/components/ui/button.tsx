// Kept for the template's landing and offline pages; the design kit's
// Button/LinkButton in ui/kit.tsx is what screens use.
export { Button } from "@/components/ui/kit";

export type ButtonVariant = "primary" | "secondary";
export function buttonClassName(variant: ButtonVariant = "primary", className = ""): string {
  const base = "press inline-flex h-[54px] w-full items-center justify-center gap-2 rounded-btn text-[16px] font-semibold no-underline";
  const v = variant === "primary" ? "bg-plum text-surface" : "border border-edge text-ink";
  return `${base} ${v} ${className}`.trim();
}
