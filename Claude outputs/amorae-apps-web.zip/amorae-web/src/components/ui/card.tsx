import type { ReactNode } from "react";

// Used sparingly: the design has at most one card per screen.
export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-card border border-line bg-surface p-5 ${className}`}>{children}</div>;
}
