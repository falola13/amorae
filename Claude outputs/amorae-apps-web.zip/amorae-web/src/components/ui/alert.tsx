import { Icon } from "@/components/icons";

export function Alert({ message, variant = "error" }: { message: string; variant?: "error" | "success" }) {
  const tone = variant === "error" ? "bg-red-tint text-red" : "bg-green-tint text-green";
  return (
    <div role={variant === "error" ? "alert" : "status"} className={`flex items-center gap-2.5 rounded-input px-3.5 py-2.5 text-support font-semibold ${tone}`}>
      <Icon name={variant === "error" ? "alert" : "check"} size={18} />
      {message}
    </div>
  );
}
