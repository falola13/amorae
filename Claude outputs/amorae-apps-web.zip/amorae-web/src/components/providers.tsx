"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState, type ReactNode } from "react";

import { isApiError } from "@/lib/api/errors";

// One QueryClient per browser tab. Server state (weeks, events, goals…) lives
// here; client state (network, prayer-mode session, install prompt) lives in
// the Zustand stores under src/lib/store.
export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            refetchOnWindowFocus: true,
            // Serve cached data while offline instead of failing the query.
            networkMode: "offlineFirst",
            retry: (count, error) => !(isApiError(error) && error.status < 500) && count < 2,
          },
          mutations: { networkMode: "offlineFirst" },
        },
      }),
  );
  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
}
