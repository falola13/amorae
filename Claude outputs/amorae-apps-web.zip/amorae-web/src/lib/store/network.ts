"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

// Connectivity plus the queue of changes made while offline. The queue is
// persisted so a change made in a tunnel survives the app being closed.
// With the real API each queued op is replayed on reconnect; the mock store
// has already applied it locally, so replay just clears the queue.
export interface QueuedOp {
  id: string;
  op: string;
  payload: unknown;
  at: string;
}

interface NetworkState {
  online: boolean;
  queue: QueuedOp[];
  justSynced: number | null;
  setOnline: (v: boolean) => void;
  enqueue: (op: string, payload: unknown) => void;
  flush: () => Promise<void>;
  isQueued: (pred: (q: QueuedOp) => boolean) => boolean;
}

export const useNetwork = create<NetworkState>()(
  persist(
    (set, get) => ({
      online: true,
      queue: [],
      justSynced: null,
      setOnline: (online) => set({ online }),
      enqueue: (op, payload) => set((s) => ({ queue: [...s.queue, { id: Math.random().toString(36).slice(2), op, payload, at: new Date().toISOString() }] })),
      flush: async () => {
        const n = get().queue.length;
        if (n === 0) return;
        await new Promise((r) => setTimeout(r, 500));
        set({ queue: [], justSynced: n });
        setTimeout(() => set({ justSynced: null }), 3500);
      },
      isQueued: (pred) => get().queue.some(pred),
    }),
    { name: "amorae:network", partialize: (s) => ({ queue: s.queue }) },
  ),
);

/** Mount once (in the app shell) to wire browser online/offline events to the store. */
export function bindNetworkEvents(onBackOnline: () => void) {
  const { setOnline, flush } = useNetwork.getState();
  setOnline(navigator.onLine);
  const up = async () => { setOnline(true); await flush(); onBackOnline(); };
  const down = () => setOnline(false);
  window.addEventListener("online", up);
  window.addEventListener("offline", down);
  return () => { window.removeEventListener("online", up); window.removeEventListener("offline", down); };
}
