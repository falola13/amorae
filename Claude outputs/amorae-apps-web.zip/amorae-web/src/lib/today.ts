import { TODAY } from "@/lib/api/mock/db";

// In mock mode the demo data is anchored to one evening so every screen
// agrees on "tonight" and "this week". With the real API this is the clock.
export const today = (): Date => (process.env.NEXT_PUBLIC_API_MOCK === "true" ? TODAY : new Date());
