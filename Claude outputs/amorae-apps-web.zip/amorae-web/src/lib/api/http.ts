"use client";

import axios, { type AxiosError, type AxiosInstance } from "axios";

import { ApiError } from "./errors";
import { mockAdapter } from "./mock/adapter";

interface ErrorEnvelope {
  error?: { code?: string; message?: string; fields?: Record<string, string>; request_id?: string };
}

const NETWORK_ERROR_MESSAGE = "We couldn't reach the server. Please try again.";
const isMock = process.env.NEXT_PUBLIC_API_MOCK === "true";

// The browser's one HTTP client. It calls /api/v1/* on this origin; the route
// handler at src/app/api/v1/[...path]/route.ts adds the session's bearer
// token and forwards to the Go API, so the token never reaches JavaScript
// (docs/adr/0002). Feature api.ts files call this, never axios directly.
export const http: AxiosInstance = axios.create({
  baseURL: "/api/v1",
  timeout: 10_000,
  headers: { Accept: "application/json" },
  // Mock mode swaps the transport, not the call sites.
  adapter: isMock ? mockAdapter : undefined,
});

// Unwrap the `{ data }` envelope and map every failure to ApiError, whose
// message is always safe to show.
http.interceptors.response.use(
  (response) => {
    if (response.status === 204 || response.data === undefined || response.data === "") return { ...response, data: undefined };
    return { ...response, data: (response.data as { data: unknown }).data };
  },
  (error: AxiosError<ErrorEnvelope>) => {
    if (!error.response) throw new ApiError(0, "network_error", NETWORK_ERROR_MESSAGE);
    const { status, data } = error.response;
    const err = data?.error;
    if (status === 401 && typeof window !== "undefined" && !/^\/(login|register|welcome)/.test(window.location.pathname)) {
      // A full navigation on purpose: the session is gone, so the client
      // cache must go with it, and the login page is a fresh document.
      window.dispatchEvent(new CustomEvent("amorae:session-expired"));
    }
    throw new ApiError(status, err?.code ?? "unknown_error", err?.message ?? "Something went wrong. Please try again.", err?.fields, err?.request_id);
  },
);

export const offline = () => typeof navigator !== "undefined" && !navigator.onLine;
