import { isApiError } from "@/lib/api/errors";

// What a Server Action returns to a React Hook Form submit handler when it
// can't redirect: a message for the top of the form and per-field errors the
// caller maps onto setError(). Never echo a password back.
export type ActionError = { message: string; fields?: Record<string, string> };

export function toActionError(error: unknown): ActionError {
  if (isApiError(error)) return { message: error.message, fields: error.fields };
  return { message: "Something went wrong. Please try again." };
}

// Kept for the template's useActionState forms (features/users). New forms
// use React Hook Form + Zod and the ActionError shape above.
export type FormState = { status: "idle" | "error" | "success"; message?: string; fields?: Record<string, string>; values?: Record<string, string> };
export const idleFormState: FormState = { status: "idle" };
export function toFormState(error: unknown, values?: Record<string, string>): FormState {
  if (isApiError(error)) return { status: "error", message: error.message, fields: error.fields, values };
  return { status: "error", message: "Something went wrong. Please try again.", values };
}
